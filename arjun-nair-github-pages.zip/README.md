# Arjun Nair — GitHub Pages portfolio

This folder contains a complete static portfolio. No installation, build step or server is required.

## Publish as a user site

1. Create a public GitHub repository named `<username>.github.io`, replacing `<username>` with your GitHub username.
2. Upload the contents of this folder directly to the repository root. `index.html`, `assets/`, `css/`, `js/`, `vendor/`, `projects/`, `education/` and `.nojekyll` must be at that root.
3. In the repository, open **Settings → Pages**, choose **Deploy from a branch**, and select **main** and **/(root)**.
4. After GitHub finishes deploying, open `https://<username>.github.io/` and check the homepage, project pages and résumé downloads.

The website uses root-relative navigation and asset URLs. It is prepared for the user-root site above. A project site such as `https://<username>.github.io/portfolio/` needs its base paths adjusted before deployment.

## Editing

Edit the HTML pages and shared files in `css/` and `js/`. All three résumé PDFs and the existing email, phone and LinkedIn links are retained unchanged. Fonts and animation libraries are bundled locally.

The package contains the current public website assets only. It does not include native CAD, original private image/video archives, Git metadata, hosting credentials or the prior hosting configuration.
