// The CAD views provide visual references, not dimensional or kinematic data.
const descriptions={assembly:'Illustrative placement · stylized infant',modular:'Reusable housing · removable syringe cartridges',exploded:'Exploded components · illustrative spacing',array:'Microneedle array · enlarged schematic'};

window.portfolioNeoSenseMode='assembly';
document.querySelectorAll('[data-neosense-mode]').forEach(button=>button.addEventListener('click',()=>{
 const mode=button.dataset.neosenseMode;if(!descriptions[mode])return;
 window.portfolioNeoSenseMode=mode;
 document.querySelectorAll('[data-neosense-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.neosenseMode===mode)));
 document.querySelectorAll('[data-neosense-status]').forEach(el=>el.textContent=descriptions[mode]);
 const station=document.querySelector('#station-view:not(.scene-ready) #station-fallback-image');
 if(station&&!document.querySelector('[data-neosense-station-controls]')?.hidden)station.src='/assets/station-1-fallback.svg';
 dispatchEvent(new CustomEvent('neosense:mode',{detail:mode}));
}));
