import * as T from 'three';

// Original visual concept informed by the supplied December 2024 BMEN 4501
// team proposal. Geometry is schematic. This is not a manufactured scaffold,
// a reconstruction of journal imagery, or a demonstration of tested outcomes.
const half={x:1.05,y:.87,z:1.05};
const MODES=['structure','printing','cells'];
const pearl=new T.MeshStandardMaterial({color:0xdeece3,metalness:.12,roughness:.43,side:T.DoubleSide});
const mint=new T.MeshStandardMaterial({color:0x82cfbf,metalness:.12,roughness:.4});
const amber=new T.MeshStandardMaterial({color:0xff9b5c,metalness:.08,roughness:.42});
const nucleus=new T.MeshStandardMaterial({color:0xf3d8a7,metalness:.02,roughness:.5});

function addMesh(parent,geometry,material,x=0,y=0,z=0){
 const mesh=new T.Mesh(geometry,material);mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;
}
function label(parent,text){
 if(typeof document==='undefined')return;
 const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=124;
 const ctx=canvas.getContext('2d');if(!ctx)return;
 ctx.fillStyle='#131e18';ctx.fillRect(0,0,1024,124);ctx.strokeStyle='#456154';ctx.lineWidth=2;ctx.strokeRect(1,1,1022,122);
 ctx.font='500 29px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#c2ddd0';ctx.fillText(text,512,62);
 const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;
 const sprite=new T.Sprite(new T.SpriteMaterial({map:texture,transparent:true,depthWrite:false}));sprite.scale.set(3.05,.37,1);sprite.position.set(0,1.47,0);parent.add(sprite);
}
function field(x,y,z){
 const X=x/half.x*Math.PI*2.05,Y=y/half.y*Math.PI*2.05,Z=z/half.z*Math.PI*2.05;
 const organic=Math.abs(Math.sin(X)*Math.cos(Y)+Math.sin(Y)*Math.cos(Z)+Math.sin(Z)*Math.cos(X))-.38;
 const radius=.085,qx=Math.abs(x)-(half.x-radius),qy=Math.abs(y)-(half.y-radius),qz=Math.abs(z)-(half.z-radius);
 const bounded=Math.hypot(Math.max(qx,0),Math.max(qy,0),Math.max(qz,0))+Math.min(Math.max(qx,qy,qz),0)-radius;
 return Math.max(organic,bounded*5);
}

// Marching tetrahedra yields an original continuous, interconnected porous
// visual rather than copying the proposal's third-party scientific figures.
function porousGeometry(){
 const nx=29,ny=25,nz=29,margin=.07;
 const sx=2*(half.x+margin)/nx,sy=2*(half.y+margin)/ny,sz=2*(half.z+margin)/nz;
 const values=new Float32Array((nx+1)*(ny+1)*(nz+1));
 const index=(x,y,z)=>(x*(ny+1)+y)*(nz+1)+z;
 const point=(x,y,z)=>[-half.x-margin+x*sx,-half.y-margin+y*sy,-half.z-margin+z*sz];
 for(let x=0;x<=nx;x++)for(let y=0;y<=ny;y++)for(let z=0;z<=nz;z++){const p=point(x,y,z);values[index(x,y,z)]=field(...p);}
 const positions=[],triangles=[],lookup=new Map();
 function vertex(p){const key=p.map(v=>Math.round(v*100000)).join(',');let n=lookup.get(key);if(n===undefined){n=positions.length/3;positions.push(...p);lookup.set(key,n);}return n;}
 function triangle(a,b,c,direction){
  const ab=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],ac=[c[0]-a[0],c[1]-a[1],c[2]-a[2]];
  const normal=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]];
  if(Math.hypot(...normal)<1e-10)return;
  if(normal.reduce((n,v,i)=>n+v*direction[i],0)<0)[b,c]=[c,b];
  triangles.push(vertex(a),vertex(b),vertex(c));
 }
 const corners=[[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
 const tetrahedra=[[0,5,1,6],[0,1,2,6],[0,2,3,6],[0,3,7,6],[0,7,4,6],[0,4,5,6]];
 for(let x=0;x<nx;x++)for(let y=0;y<ny;y++)for(let z=0;z<nz;z++){
  const points=corners.map(c=>point(x+c[0],y+c[1],z+c[2]));
  const scalar=corners.map(c=>values[index(x+c[0],y+c[1],z+c[2])]);
  for(const tet of tetrahedra){
   const inside=tet.filter(i=>scalar[i]<=0),outside=tet.filter(i=>scalar[i]>0);if(!inside.length||!outside.length)continue;
   const dir=[0,1,2].map(axis=>outside.reduce((n,i)=>n+points[i][axis]/outside.length,0)-inside.reduce((n,i)=>n+points[i][axis]/inside.length,0));
   const cross=(a,b)=>{const amount=scalar[a]/(scalar[a]-scalar[b]);return points[a].map((v,axis)=>v+(points[b][axis]-v)*amount);};
   if(inside.length===1){const p=outside.map(i=>cross(inside[0],i));triangle(p[0],p[1],p[2],dir);}
   else if(outside.length===1){const p=inside.map(i=>cross(i,outside[0]));triangle(p[0],p[1],p[2],dir);}
   else{const a=cross(inside[0],outside[0]),b=cross(inside[0],outside[1]),c=cross(inside[1],outside[0]),d=cross(inside[1],outside[1]);triangle(a,b,c,dir);triangle(b,d,c,dir);}
  }
 }
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(positions,3));geometry.setIndex(triangles);geometry.computeVertexNormals();geometry.computeBoundingBox();geometry.computeBoundingSphere();
 return geometry;
}
function sliceGeometries(full,count){
 const buckets=Array.from({length:count},()=>[]),pos=full.attributes.position,indices=full.index.array;
 for(let i=0;i<indices.length;i+=3){
  const y=(pos.getY(indices[i])+pos.getY(indices[i+1])+pos.getY(indices[i+2]))/3;
  const layer=Math.max(0,Math.min(count-1,Math.floor((y+half.y)/(half.y*2)*count)));buckets[layer].push(indices[i],indices[i+1],indices[i+2]);
 }
 return buckets.map(indices=>{const g=new T.BufferGeometry();g.setAttribute('position',full.attributes.position);g.setAttribute('normal',full.attributes.normal);g.setIndex(indices);g.computeBoundingBox();g.computeBoundingSphere();return g;});
}

export function createScaffold(){
 const group=new T.Group(),turntable=new T.Group();group.add(turntable);group.scale.setScalar(.9);
 addMesh(group,new T.CylinderGeometry(1.64,1.64,.065,80),new T.MeshStandardMaterial({color:0x24372d,roughness:.65,metalness:.18}),0,-1.32,0);
 const rim=addMesh(group,new T.TorusGeometry(1.60,.012,8,96),mint,0,-1.279,0);rim.rotation.x=Math.PI/2;
 label(group,'dECM–GelMA / DESIGN CONCEPT');
 const geometry=porousGeometry(),structure=addMesh(turntable,geometry,pearl);
 const cellMaterial=pearl.clone();cellMaterial.transparent=true;cellMaterial.opacity=.62;cellMaterial.depthWrite=false;
 const layerRoot=new T.Group();turntable.add(layerRoot);
 const layerMaterials=sliceGeometries(geometry,9).map((g,i)=>{const m=pearl.clone();m.emissive=new T.Color(0x94d8c6);m.emissiveIntensity=0;return addMesh(layerRoot,g,m);});
 const projectorRoot=new T.Group();turntable.add(projectorRoot);
 const lightPlane=addMesh(projectorRoot,new T.PlaneGeometry(2.35,2.35),new T.MeshBasicMaterial({color:0x92e7d2,transparent:true,opacity:.17,side:T.DoubleSide,depthWrite:false}));lightPlane.rotation.x=-Math.PI/2;
 const outlinePoints=[[-1.18,0,-1.18],[1.18,0,-1.18],[1.18,0,1.18],[-1.18,0,1.18],[-1.18,0,-1.18]].map(p=>new T.Vector3(...p));
 const lightOutline=new T.Line(new T.BufferGeometry().setFromPoints(outlinePoints),new T.LineBasicMaterial({color:0xa0f1d7,transparent:true,opacity:.7}));projectorRoot.add(lightOutline);
 // Cells show an illustrative distribution only; no growth or viability result.
 const cells=new T.Group();turntable.add(cells);const cellMeshes=[];
 let seed=41073;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 for(let attempts=0;cellMeshes.length<15&&attempts<5000;attempts++){
  const p=[(random()*2-1)*.88,(random()*2-1)*.72,(random()*2-1)*.88];
  if(field(...p)<.3)continue;
  const cell=new T.Group();cell.position.set(...p);const radius=.055+random()*.027;
  const body=addMesh(cell,new T.SphereGeometry(radius,16,12),amber);body.scale.set(1.1,.85,1);
  addMesh(cell,new T.SphereGeometry(radius*.36,12,8),nucleus,0,0,radius*.75);
  cell.userData.phase=random()*Math.PI*2;cellMeshes.push(cell);cells.add(cell);
 }
 let mode='structure',modeStart=null,lastT=0;
 function setMode(value){
  mode=MODES.includes(value)?value:'structure';modeStart=null;
  structure.visible=mode!=='printing';structure.material=mode==='cells'?cellMaterial:pearl;
  layerRoot.visible=mode==='printing';projectorRoot.visible=mode==='printing';cells.visible=mode==='cells';
  layerMaterials.forEach((mesh,i)=>{mesh.visible=i===0;mesh.material.emissiveIntensity=i===0?.12:0;});
  projectorRoot.position.y=-half.y+.025;
  return mode;
 }
 function animate(t=0){
  if(!Number.isFinite(t))t=lastT;lastT=t;
  const requested=typeof window!=='undefined'?window.portfolioScaffoldMode:mode;
  if(requested&&requested!==mode)setMode(requested);
  if(modeStart===null)modeStart=t;
  turntable.rotation.y=.19+Math.sin(t*.19)*.25;
  if(mode==='printing'){
   const progress=Math.min(1,((t-modeStart)%14)/10),layer=Math.min(8,Math.floor(progress*9));
   layerMaterials.forEach((mesh,i)=>{mesh.visible=i<=layer;mesh.material.emissiveIntensity=i===layer?.16:0;});
   projectorRoot.position.y=-half.y+progress*half.y*2+.025;
  }
  if(mode==='cells')cellMeshes.forEach((cell,i)=>{cell.scale.setScalar(1+.035*Math.sin(t*.8+cell.userData.phase));});
 }
 setMode(typeof window!=='undefined'?window.portfolioScaffoldMode:'structure');animate(0);
 return{group,animate,setMode,getMode:()=>mode};
}
