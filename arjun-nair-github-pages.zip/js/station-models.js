import * as T from 'three';
import {createNeoSense} from './neosense-model.js';
import {createPoppie} from './poppie-model.js';
import {createScaffold} from './scaffold-model.js';
import {createSmartStent} from './stent-model.js';
import {createLipidNanoparticle} from './lipid-model.js';

// Procedural concept illustrations: scale and geometry are schematic, not device CAD.
export const orange=new T.MeshStandardMaterial({color:0xff8a45,metalness:.38,roughness:.35});
const dark=new T.MeshStandardMaterial({color:0x303b33,metalness:.5,roughness:.45});
const steel=new T.MeshStandardMaterial({color:0xc8d1be,metalness:.6,roughness:.3});
const mint=new T.MeshStandardMaterial({color:0x85d9cc,metalness:.28,roughness:.42});
const glow=new T.MeshStandardMaterial({color:0x85e8df,emissive:0x66cabe,emissiveIntensity:.35,roughness:.4});
const membrane=new T.MeshStandardMaterial({color:0x81c9bd,transparent:true,opacity:.12,roughness:.45,side:T.DoubleSide,depthWrite:false});
export function mesh(parent,geo,mat,x=0,y=0,z=0){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
export function box(g,w,h,d,m,x=0,y=0,z=0){return mesh(g,new T.BoxGeometry(w,h,d),m,x,y,z);}
export function cyl(g,r,h,m,x=0,y=0,z=0){return mesh(g,new T.CylinderGeometry(r,r,h,32),m,x,y,z);}
function sphere(g,r,m,x=0,y=0,z=0){return mesh(g,new T.SphereGeometry(r,16,12),m,x,y,z);}
function bond(g,a,b,r=.025,m=steel){const start=new T.Vector3(...a),end=new T.Vector3(...b),d=end.clone().sub(start);const rod=cyl(g,r,d.length(),m);rod.position.copy(start.add(end).multiplyScalar(.5));rod.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());return rod;}
function line(g,pts,color=0x83cdbf){const path=new T.Line(new T.BufferGeometry().setFromPoints(pts.map(p=>new T.Vector3(...p))),new T.LineBasicMaterial({color,transparent:true,opacity:.5}));g.add(path);return path;}
function label(g,text,w=2.8,y=1.65){const c=document.createElement('canvas');c.width=768;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#141d17';ctx.fillRect(0,0,768,128);ctx.strokeStyle='#46594b';ctx.lineWidth=2;ctx.strokeRect(1,1,766,126);ctx.font='500 31px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#9edccc';ctx.fillText(text,384,64);const texture=new T.CanvasTexture(c);texture.colorSpace=T.SRGBColorSpace;return mesh(g,new T.PlaneGeometry(w,.46),new T.MeshBasicMaterial({map:texture}),0,y,0);}
function platform(g){cyl(g,1.75,.1,dark,0,-1.5,0);const rim=mesh(g,new T.TorusGeometry(1.72,.012,8,80),glow,0,-1.44,0);rim.rotation.x=Math.PI/2;for(let i=-2;i<=2;i++)line(g,[[-1.3,-1.435,i*.5],[1.3,-1.435,i*.5]],0x4c6253);}
function stage(title){const g=new T.Group();platform(g);label(g,title);return g;}

function docking(){
 const g=stage('MOLECULAR DOCKING / CONCEPT'),protein=new T.Group();g.add(protein);protein.position.set(-.32,0,0);
 const atoms=[];for(let i=0;i<27;i++){const a=i*.72,p=[Math.cos(a)*(.62+.15*Math.sin(i)),(i/26-.5)*1.85,Math.sin(a)*.55];atoms.push(p);sphere(protein,.12,i%6===0?orange:steel,...p);if(i)bond(protein,atoms[i-1],p,.038,dark);if(i>4&&i%3===0)bond(protein,atoms[i-4],p,.018,mint);}
 const ligand=new T.Group();g.add(ligand);for(let i=0;i<6;i++){const a=i*Math.PI/3,p=[Math.cos(a)*.3,Math.sin(a)*.3,0],q=[Math.cos(a+Math.PI/3)*.3,Math.sin(a+Math.PI/3)*.3,0];sphere(ligand,.095,i%2?orange:glow,...p);bond(ligand,p,q,.028,orange);}sphere(ligand,.08,steel,.58,0,0);bond(ligand,[.3,0,0],[.58,0,0],.025,orange);
 line(g,[[1.7,.3,.3],[.8,.15,.2],[.15,.02,.15]],0x85e8df);
 return{group:g,animate:t=>{protein.rotation.y=Math.sin(t*.3)*.15;ligand.position.set(.78+.15*Math.sin(t*.45),.08+.05*Math.cos(t),.65);ligand.rotation.y=Math.sin(t*.5)*.35;}};
}
function biomarkers(){
 const g=stage('CANCER BIOMARKERS / ASSAY CONCEPT'),plate=new T.Group();g.add(plate);plate.rotation.y=.12;box(plate,2.7,.16,1.7,steel,0,-.45,0);
 for(let x=0;x<6;x++)for(let z=0;z<4;z++){const px=(x-2.5)*.39,pz=(z-1.5)*.38;cyl(plate,.12,.035,dark,px,-.345,pz);cyl(plate,.085,.018,(x+z)%4===0?orange:mint,px,-.322,pz);}
 const tube=new T.Group();tube.position.set(-1.1,.35,-.45);g.add(tube);cyl(tube,.2,.85,membrane);cyl(tube,.165,.4,mint,0,-.2,0);cyl(tube,.23,.16,orange,0,.5,0);const marker=sphere(g,.16,orange,.9,.95,.2);sphere(g,.095,glow,1.23,.72,.2);sphere(g,.1,steel,.75,.62,.2);bond(g,[.9,.95,.2],[1.23,.72,.2],.025,mint);bond(g,[.9,.95,.2],[.75,.62,.2],.025,mint);line(g,[[-.85,.35,-.45],[.1,.8,-.2],[.9,.95,.2]]);
 return{group:g,animate:t=>{plate.rotation.y=.12+Math.sin(t*.25)*.12;marker.scale.setScalar(1+.07*Math.sin(t*1.2));}};
}
export function createStations(){return[createNeoSense(),createPoppie(),createSmartStent(),createScaffold(),createLipidNanoparticle(),docking(),biomarkers()];}
