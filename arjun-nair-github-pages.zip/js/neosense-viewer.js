import * as THREE from 'three';
import {createNeoSense} from './neosense-model.js';

const view=document.getElementById('neosense-viewer');
if(view){
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),motion=document.querySelector('[data-neosense-motion]');
 let renderer,model,camera,scene,orbit,visible=false,frameId=0,last=0,clock=0,paused=reduced.matches,baseZoom=1;
 const syncMotion=()=>{motion.textContent=paused?'Resume animation':'Pause animation';motion.setAttribute('aria-pressed',String(paused));};
 const render=()=>{model?.animate(clock);if(camera){const p=model?.getMode()==='assembly'?model.getPresentation():null;camera.position.set(...(p?.position||[4.3,2.5,6.5]));camera.zoom=baseZoom*(p?.zoom||1);camera.lookAt(...(p?.focus||[0,.15,0]));camera.updateProjectionMatrix();if(p){const status=document.querySelector('.neosense-lab [data-neosense-status]');if(status)status.textContent=p.phase;}}renderer?.render(scene,camera);};
 const frame=now=>{frameId=0;if(document.hidden||!visible||document.querySelector('dialog[open]')){last=0;return;}const dt=last?Math.min(.06,(now-last)/1000):0;last=now;if(!paused)clock+=dt;render();if(!paused)frameId=requestAnimationFrame(frame);};
 const request=()=>{if(renderer&&!frameId&&!document.hidden)frameId=requestAnimationFrame(frame);};
 try{
  renderer=new THREE.WebGLRenderer({alpha:true,antialias:true});renderer.setPixelRatio(Math.min(2,devicePixelRatio||1));renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
  renderer.domElement.setAttribute('role','img');renderer.domElement.setAttribute('aria-label','NeoSense applicator and microneedle array: interactive schematic informed by the supplied design files.');view.append(renderer.domElement);
  scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(37,1,.1,50);camera.position.set(4.3,2.5,6.5);camera.lookAt(0,.15,0);
  scene.add(new THREE.HemisphereLight(0xf0f6f1,0x303b38,2.5));
  for(const [color,intensity,position]of [[0xfff2df,4,[3,6,4]],[0xa4c8e2,2,[-4,3,-3]],[0xff8a45,1.2,[4,2,-3]]]){const light=new THREE.DirectionalLight(color,intensity);light.position.set(...position);scene.add(light);}
  model=createNeoSense();orbit=new THREE.Group();orbit.add(model.group);scene.add(orbit);view.classList.add('scene-ready');view.dataset.ready='true';
  let pointer=null;
  renderer.domElement.style.touchAction='pan-y';
  renderer.domElement.addEventListener('pointerdown',e=>{if(!renderer||e.pointerType!=='mouse'||e.button!==0)return;pointer={id:e.pointerId,x:e.clientX,y:e.clientY};renderer.domElement.setPointerCapture(e.pointerId);view.classList.add('is-dragging');});
  renderer.domElement.addEventListener('pointermove',e=>{if(!renderer||!pointer||pointer.id!==e.pointerId)return;orbit.rotation.y+=(e.clientX-pointer.x)*.008;orbit.rotation.x=THREE.MathUtils.clamp(orbit.rotation.x+(e.clientY-pointer.y)*.003,-.35,.35);pointer.x=e.clientX;pointer.y=e.clientY;render();});
  const release=()=>{pointer=null;view.classList.remove('is-dragging');};
  renderer.domElement.addEventListener('pointerup',release);renderer.domElement.addEventListener('pointercancel',release);
  new ResizeObserver(()=>{if(!renderer)return;const w=view.clientWidth,h=view.clientHeight;if(!w||!h)return;camera.aspect=w/h;baseZoom=Math.min(1.1,w/h*1.25);camera.updateProjectionMatrix();renderer.setSize(w,h,false);render();}).observe(view);
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;last=0;request();},{threshold:.03}).observe(view);
  addEventListener('neosense:mode',()=>{clock=0;last=0;render();request();});
  addEventListener('portfolio:dialog',()=>{last=0;request();});
  document.addEventListener('visibilitychange',()=>{last=0;request();});
  motion.addEventListener('click',()=>{paused=!paused;syncMotion();last=0;request();});
  reduced.addEventListener('change',e=>{if(e.matches)paused=true;syncMotion();request();});
  renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();view.classList.remove('scene-ready');view.dataset.ready='false';if(frameId)cancelAnimationFrame(frameId);renderer=null;motion.disabled=true;document.querySelector('[data-neosense-status]').textContent='3D unavailable · design illustration shown';});
  syncMotion();render();
 }catch(error){
  renderer?.dispose();renderer=null;motion.hidden=true;
  document.querySelectorAll('.neosense-lab [data-neosense-mode]').forEach(b=>b.disabled=true);
  document.querySelector('.neosense-lab [data-neosense-status]').textContent='3D unavailable · design illustration shown';
  console.warn('NeoSense illustrated fallback:',error.message);
 }
}
