import * as T from 'three';

// Stylized product presentation guided by supplied NeoSense CAD and screenshots.
// The placement box is intentionally absent. Geometry and exploded spacing are illustrative.
const pearl=new T.MeshStandardMaterial({color:0xd6d9d7,metalness:.35,roughness:.3});
const shell=new T.MeshStandardMaterial({color:0x9da8b3,metalness:.45,roughness:.32,side:T.DoubleSide});
const titanium=new T.MeshStandardMaterial({color:0x566473,metalness:.58,roughness:.3});
const silver=new T.MeshStandardMaterial({color:0xc6d2d7,metalness:.7,roughness:.23});
const dark=new T.MeshStandardMaterial({color:0x1b292c,metalness:.35,roughness:.5});
const orange=new T.MeshStandardMaterial({color:0xff9a59,metalness:.28,roughness:.34});
const mint=new T.MeshStandardMaterial({color:0x99dacf,metalness:.25,roughness:.42});
const clear=new T.MeshPhysicalMaterial({color:0xc4e1df,metalness:.08,roughness:.16,transparent:true,opacity:.24,depthWrite:false,side:T.DoubleSide});
const clearHousing=new T.MeshPhysicalMaterial({color:0xc7dce2,metalness:.03,roughness:.18,transparent:true,opacity:.17,depthWrite:false,side:T.DoubleSide});
const syringeGlass=new T.MeshPhysicalMaterial({color:0xb9e7ec,metalness:.02,roughness:.1,transparent:true,opacity:.56,depthWrite:false,side:T.DoubleSide});
const mannequinSkin=new T.MeshStandardMaterial({color:0xd7b7a2,metalness:.01,roughness:.82});
const clothing=new T.MeshStandardMaterial({color:0xa2c9c1,metalness:.02,roughness:.82});
const diaper=new T.MeshStandardMaterial({color:0xe7e7dc,metalness:.01,roughness:.9});
const blanketMat=new T.MeshStandardMaterial({color:0x597b77,metalness:.01,roughness:.96});
function mesh(g,geometry,material,x=0,y=0,z=0){const m=new T.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;g.add(m);return m;}
function box(g,w,h,d,m,x=0,y=0,z=0){return mesh(g,new T.BoxGeometry(w,h,d),m,x,y,z);}
function cylinder(g,r,h,m,x=0,y=0,z=0){return mesh(g,new T.CylinderGeometry(r,r,h,48),m,x,y,z);}
function torus(g,r,t,m,x=0,y=0,z=0){const o=mesh(g,new T.TorusGeometry(r,t,8,64),m,x,y,z);o.rotation.x=Math.PI/2;return o;}
function roundedBox(g,w,h,d,material,x=0,y=0,z=0,r=.045){
 r=Math.min(r,w/3,h/3);const s=new T.Shape(),left=-w/2,bottom=-h/2;
 s.moveTo(left+r,bottom);s.lineTo(left+w-r,bottom);s.quadraticCurveTo(left+w,bottom,left+w,bottom+r);s.lineTo(left+w,bottom+h-r);s.quadraticCurveTo(left+w,bottom+h,left+w-r,bottom+h);s.lineTo(left+r,bottom+h);s.quadraticCurveTo(left,bottom+h,left,bottom+h-r);s.lineTo(left,bottom+r);s.quadraticCurveTo(left,bottom,left+r,bottom);
 const geo=new T.ExtrudeGeometry(s,{depth:d,bevelEnabled:true,bevelThickness:Math.min(.014,d/4),bevelSize:.012,bevelSegments:3,curveSegments:8});geo.translate(0,0,-d/2);return mesh(g,geo,material,x,y,z);
}
function ringTube(g,ro,ri,h,material,x=0,y=0,z=0){
 const s=new T.Shape();s.absarc(0,0,ro,0,Math.PI*2,false);const hole=new T.Path();hole.absarc(0,0,ri,0,Math.PI*2,true);s.holes.push(hole);
 const geo=new T.ExtrudeGeometry(s,{depth:h,bevelEnabled:false,curveSegments:48});geo.rotateX(Math.PI/2);geo.translate(0,h/2,0);return mesh(g,geo,material,x,y,z);
}
function label(g,text,y=1.67){
 if(typeof document==='undefined')return;
 const c=document.createElement('canvas');c.width=768;c.height=112;const ctx=c.getContext('2d');ctx.fillStyle='#141d17';ctx.fillRect(0,0,768,112);ctx.strokeStyle='#46594b';ctx.strokeRect(1,1,766,110);ctx.fillStyle='#b9d6cf';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='500 26px monospace';ctx.fillText(text,384,56);
 const texture=new T.CanvasTexture(c);texture.colorSpace=T.SRGBColorSpace;return mesh(g,new T.PlaneGeometry(2.95,.43),new T.MeshBasicMaterial({map:texture}),0,y,0);
}
function needles(g,size,n,height=.11,down=false){
 const geo=new T.ConeGeometry(size*.009,height,6),instances=new T.InstancedMesh(geo,silver,n*n),dummy=new T.Object3D(),spacing=(size-.09)/(n-1);let i=0;
 for(let x=0;x<n;x++)for(let z=0;z<n;z++){dummy.position.set((x-(n-1)/2)*spacing,down?-height/2:height/2,(z-(n-1)/2)*spacing);dummy.rotation.set(down?Math.PI:0,(x+z)%2*Math.PI/6,0);dummy.updateMatrix();instances.setMatrixAt(i++,dummy.matrix);}
 instances.castShadow=true;instances.receiveShadow=true;instances.instanceMatrix.needsUpdate=true;g.add(instances);return instances;
}
function makeArray(size=2.24,n=25){
 const g=new T.Group();roundedBox(g,size,.055,size,pearl,0,0,0,.018);box(g,size-.07,.018,size-.07,silver,0,.035,0);
 const spikes=new T.Group();spikes.position.y=.046;g.add(spikes);needles(spikes,size-.05,n,.125);cylinder(g,.088,.20,silver,0,-.128,0);torus(g,.088,.01,titanium,0,-.226,0);return g;
}
function makeCartridge(){
 const g=new T.Group();cylinder(g,.177,.09,pearl);cylinder(g,.052,.16,silver,0,.102,0);for(let y=.05;y<.15;y+=.025)torus(g,.06,.009,titanium,0,y,0);
 const patch=new T.Group();patch.position.y=-.057;g.add(patch);box(patch,.19,.014,.19,silver);needles(patch,.17,5,.033,true);return g;
}
function makeBarrel(radius=.295,length=1.24){
 const g=new T.Group();cylinder(g,radius,length,clear);torus(g,radius,.016,pearl,0,length/2,0);torus(g,radius,.016,titanium,0,-length/2,0);
 // A distinct standard syringe is nested INSIDE the larger reusable housing.
 const inner=radius*.51,barrelLength=length*.75;
 const innerBarrel=cylinder(g,inner,barrelLength,syringeGlass,0,-.045,0);innerBarrel.name='visible-inner-syringe-barrel';
 ringTube(g,inner*1.05,inner*.86,.025,pearl,0,barrelLength/2-.045,0);
 const flange=box(g,inner*2.75,.028,inner*1.12,pearl,0,barrelLength/2-.025,0);flange.name='syringe-finger-flange';
 const seal=cylinder(g,inner*.88,.045,titanium,0,length*.035,0);seal.name='syringe-piston-seal';
 cylinder(g,inner*.20,length*.65,silver,0,length*.36,0);
 const outlet=mesh(g,new T.CylinderGeometry(inner*.64,inner*.18,.15,32),pearl,0,-barrelLength/2-.115,0);outlet.name='syringe-taper-outlet';
 for(let i=0;i<6;i++){const tick=box(g,i%2?.055:.085,.007,.008,mint,radius*.52,(i-2.5)*.105,radius*.86);tick.rotation.y=-.45;}return g;
}
function soft(g,r,material,x,y,z,sx=1,sy=1,sz=1){const m=mesh(g,new T.SphereGeometry(r,28,18),material,x,y,z);m.scale.set(sx,sy,sz);return m;}
function limb(g,start,end,r,material){
 const a=new T.Vector3(...start),b=new T.Vector3(...end),delta=b.clone().sub(a),m=mesh(g,new T.CapsuleGeometry(r,delta.length(),5,18),material);m.position.copy(a.add(b).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return m;
}
function createNewborn(){
 const g=new T.Group();g.name='clothed-newborn-mannequin';
 const blanket=roundedBox(g,3.55,1.48,.075,blanketMat,0,-1.075,0,.18);blanket.rotation.x=Math.PI/2;
 // Opaque onesie and diaper cover the torso/pelvis; smooth limbs are non-anatomical.
 soft(g,.34,mannequinSkin,-1.25,-.55,0,.96,1,.92);
 soft(g,.33,clothing,-.62,-.69,0,1.5,.83,1);
 soft(g,.31,diaper,.09,-.69,0,1.24,.88,1.08);
 for(const side of [-1,1]){
  limb(g,[-.86,-.71,side*.29],[-.53,-.76,side*.57],.105,clothing);
  limb(g,[-.53,-.76,side*.57],[-.26,-.77,side*.57],.085,mannequinSkin);soft(g,.105,mannequinSkin,-.16,-.76,side*.55,.9,.75,1);
  limb(g,[.36,-.73,side*.23],[.85,-.76,side*.40],.16,mannequinSkin);
  limb(g,[.85,-.76,side*.40],[1.19,-.86,side*.28],.115,mannequinSkin);
  soft(g,.15,mannequinSkin,1.35,-.86,side*.28,1.05,.65,.8);
 }
 // Minimal sleepy facial marks make the mannequin recognizable without realism.
 const faceMat=new T.LineBasicMaterial({color:0x68594e,transparent:true,opacity:.7});
 for(const z of [-.11,.11]){
  const points=[[-1.29,-.218,z-.04],[-1.27,-.215,z],[-1.29,-.218,z+.04]].map(p=>new T.Vector3(...p));g.add(new T.Line(new T.BufferGeometry().setFromPoints(points),faceMat));
 }
 soft(g,.025,mannequinSkin,-1.17,-.215,0,.75,.6,.8);
 const mouth=[[-1.07,-.245,-.035],[-1.055,-.243,0],[-1.07,-.245,.035]].map(p=>new T.Vector3(...p));g.add(new T.Line(new T.BufferGeometry().setFromPoints(mouth),faceMat));
 return g;
}

export function createNeoSense(){
 const group=new T.Group(),turntable=new T.Group();group.add(turntable);turntable.rotation.y=-.2;group.scale.setScalar(.88);group.position.y=.12;
 const plinth=cylinder(group,1.62,.05,new T.MeshStandardMaterial({color:0x22332c,roughness:.63,metalness:.28}),0,-1.45,0);plinth.name='presentation-turntable';const plinthRim=torus(group,1.59,.01,mint,0,-1.42,0);
 label(group,'NEOSENSE / NEONATAL MONITORING CONCEPT');
 const newborn=createNewborn();turntable.add(newborn);
 const assembly=new T.Group();turntable.add(assembly);
 const holder=new T.Group();assembly.add(holder);holder.name='reusable-housing';
 ringTube(holder,.385,.32,.54,pearl,0,-.57,0);torus(holder,.372,.014,silver,0,-.29,0);
 for(const side of [-1,1]){
  roundedBox(holder,.24,.075,.69,pearl,side*.31,-.935,0,.018);roundedBox(holder,.15,.18,.43,pearl,side*.30,-.83,-.02,.04);
  const latch=new T.Group();latch.position.set(side*.39,-.55,.055);holder.add(latch);roundedBox(latch,.055,.16,.11,titanium);
  const lever=roundedBox(latch,.047,.27,.05,silver,side*.024,-.015,.05,.012);lever.rotation.z=-side*.14;cylinder(latch,.027,.074,orange,side*.014,.055,.12).rotation.x=Math.PI/2;
  for(let j=0;j<4;j++)torus(latch,.026,.006,titanium,side*.013,-.095+j*.015,-.02);
 }
 roundedBox(holder,.06,.16,.027,titanium,0,-.48,.385,.01);
 // Central receiver and spring are visible through the opening between the U-shaped feet.
 cylinder(holder,.063,.38,silver,0,-.49,0);ringTube(holder,.12,.068,.10,titanium,0,-.746,0);
 const springPoints=[];for(let i=0;i<=160;i++){const a=i/160*Math.PI*10;springPoints.push(new T.Vector3(Math.cos(a)*.09,-.62-i/160*.20,Math.sin(a)*.09));}
 mesh(holder,new T.TubeGeometry(new T.CatmullRomCurve3(springPoints),160,.008,6,false),silver);
 const syringeModule=new T.Group();assembly.add(syringeModule);syringeModule.name='removable-syringe-cartridge';
 const barrel=makeBarrel();barrel.position.y=.31;syringeModule.add(barrel);barrel.name='syringe-barrel';
 const cap=new T.Group();assembly.add(cap);cap.name='reusable-transparent-housing';mesh(cap,new T.CylinderGeometry(.308,.308,1.08,48,1,true,Math.PI*.4,Math.PI),clearHousing,0,.31,0);
 for(const x of [-.302,.302])box(cap,.018,1.08,.025,shell,x,.31,0);
 for(const y of [-.16,.77]){roundedBox(cap,.05,.075,.07,titanium,-.307,y,-.015,.01);cylinder(cap,.021,.08,silver,-.307,y,-.015).rotation.x=Math.PI/2;}
 const plunger=new T.Group();syringeModule.add(plunger);plunger.name='syringe-plunger';cylinder(plunger,.052,.26,silver,0,1.06,0);cylinder(plunger,.092,.085,titanium,0,.935,0);
 const thumb=roundedBox(plunger,.37,.082,.25,pearl,0,1.23,0,.025);thumb.rotation.y=-.08;roundedBox(plunger,.035,.22,.055,titanium,.145,1.04,-.025,.01);roundedBox(plunger,.13,.035,.07,shell,.09,1.145,-.025,.01);cylinder(plunger,.024,.08,orange,.15,1.04,.035).rotation.x=Math.PI/2;
 const cartridge=makeCartridge();cartridge.position.y=-.875;assembly.add(cartridge);cartridge.name='distinct-microneedle-interface';
 const arrayView=makeArray();arrayView.position.y=-.15;arrayView.visible=false;turntable.add(arrayView);
 const options=new T.Group();options.visible=false;turntable.add(options);options.name='interchangeable-options';const optionModules=[];
 for(let i=0;i<3;i++){
  const option=new T.Group();options.add(option);option.position.set(.58+(i%2)*.48,-.22+(i===2?.8:0),.12-(i%2)*.12);option.rotation.z=-.12;
  const r=[.12,.155,.105][i],h=[.66,.88,.57][i];const insert=makeBarrel(r,h);option.add(insert);cylinder(option,.03,.18,silver,0,h/2+.085,0);roundedBox(option,r*2.3,.035,.12,i===1?orange:pearl,0,h/2+.18,0,.012);cylinder(option,.032,.10,titanium,0,-h/2-.04,0);optionModules.push(option);
 }
 const tracks=new T.Group();options.add(tracks);for(let i=0;i<7;i++){const d=mesh(tracks,new T.SphereGeometry(.014,8,6),mint,-.06+i*.075,-.1,.13);d.castShadow=false;}
 let mode='assembly',presentation={zoom:1,phase:'Illustrative external contact',from:'wide',to:'wide',blend:0};
 const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
 const reducedMotion=()=>typeof matchMedia==='function'&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 function setMode(value){
  mode=['assembly','exploded','array','modular'].includes(value)?value:'assembly';const exploded=mode==='exploded',modular=mode==='modular';
  const placement=mode==='assembly';assembly.visible=mode!=='array';arrayView.visible=mode==='array';newborn.visible=placement;options.visible=modular;plinth.visible=!placement;plinthRim.visible=!placement;
  assembly.position.set(placement?.60:modular?-.68:0,placement?-.428:exploded?-.06:modular?-.20:0,placement?.20:0);assembly.scale.setScalar(placement?.17:exploded?.85:modular?.64:1);holder.position.set(0,0,0);barrel.position.set(0,exploded?.42:.31,0);syringeModule.position.set(0,modular?1.2:0,0);
  cap.position.set(exploded?.73:0,exploded?.19:0,exploded?-.14:0);cap.rotation.z=exploded?-.1:0;plunger.position.set(exploded?-.5:0,exploded?.05:0,0);cartridge.position.set(exploded?-.72:0,exploded?-.62:-.875,exploded?.32:0);
  cap.visible=true;barrel.visible=true;plunger.visible=true;arrayView.rotation.set(0,0,0);presentation={zoom:1,phase:placement?'Illustrative external contact':'Product concept',from:'wide',to:'wide',blend:0};return mode;
 }
 setMode(typeof window!=='undefined'?window.portfolioNeoSenseMode:'assembly');
 function animate(t=0){
  const requested=typeof window!=='undefined'?window.portfolioNeoSenseMode:mode;if(requested&&requested!==mode)setMode(requested);turntable.rotation.y=mode==='assembly'?-.2:-.2+Math.sin(t*.2)*.28;
  if(mode==='assembly'){
   const time=((t%14)+14)%14;let lift=.36,zoom=4,from='product',to='product',blend=0,phase='NeoSense product focus';
   if(reducedMotion()){lift=0;zoom=1;from=to='wide';phase='Illustrative external contact';}
   else if(time<2){}
   else if(time<4){blend=smooth((time-2)/2);zoom=4-3*blend;from='product';to='wide';phase='Pull back to the newborn';}
   else if(time<6){lift=.36*(1-smooth((time-4)/2));zoom=1;from=to='wide';phase='Gently lowering to external contact';}
   else if(time<8){lift=0;blend=smooth((time-6)/2);zoom=1+2.4*blend;from='wide';to='contact';phase='Focus on illustrative thigh contact';}
   else if(time<10.5){lift=0;zoom=3.4;from=to='contact';phase='External contact · illustrative placement';}
   else if(time<12){lift=0;blend=smooth((time-10.5)/1.5);zoom=3.4-2.4*blend;from='contact';to='wide';phase='Pull back';}
   else if(time<13){lift=.36*smooth(time-12);zoom=1;from=to='wide';phase='Reset the presentation';}
   else{blend=smooth(time-13);zoom=1+3*blend;from='wide';to='product';phase='Return to product focus';}
   assembly.position.y=-.428+lift;presentation={zoom,phase,from,to,blend};
  }
  if(mode==='array')arrayView.position.y=-.15+Math.sin(t*.6)*.026;
  if(mode==='modular'){optionModules.forEach((option,i)=>option.rotation.y=Math.sin(t*.3+i)*.10);syringeModule.position.y=.02+(Math.sin(t*.65)+1)*.59;}
 }
 function getPresentation(){
  group.updateWorldMatrix(true,true);
  const points={wide:new T.Vector3(0,.15,0),product:assembly.localToWorld(new T.Vector3(0,.35,0)),contact:turntable.localToWorld(new T.Vector3(.60,-.60,.20))};
  const focus=points[presentation.from].clone().lerp(points[presentation.to],presentation.blend);
  const lowWeight=presentation.from==='contact'?(presentation.to==='contact'?1:1-presentation.blend):presentation.to==='contact'?presentation.blend:0;
  const position=new T.Vector3(4.3,2.5,6.5).lerp(new T.Vector3(3.6,1.2,5.6),lowWeight);
  return {zoom:presentation.zoom,focus:focus.toArray(),position:position.toArray(),phase:presentation.phase};
 }
 return {group,animate,setMode,getMode:()=>mode,getPresentation};
}
