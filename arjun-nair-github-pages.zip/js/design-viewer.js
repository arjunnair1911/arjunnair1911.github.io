import * as THREE from 'three';
import {createPoppie} from './poppie-model.js';
import {createScaffold} from './scaffold-model.js';
import {createSmartStent} from './stent-model.js';
import {createLipidNanoparticle} from './lipid-model.js';

const view=document.querySelector('#design-viewer[data-design-viewer]');
if(view){
 const project=view.dataset.designViewer;
 const config={
  poppie:{factory:createPoppie,global:'portfolioPoppieMode',initial:'cycle',label:'POPPIE five-petal support: original mechanical concept illustration',captions:{cycle:'Animated fold and release',expanded:'Expanded support',compressed:'Compressed inside sleeve'}},
  scaffold:{factory:createScaffold,global:'portfolioScaffoldMode',initial:'structure',label:'dECM-GelMA porous scaffold: original design concept illustration',captions:{structure:'Design concept',printing:'Layer build',cells:'Cell distribution'}},
  stent:{factory:createSmartStent,global:'portfolioStentMode',initial:'release',label:'Smart stent with a small square reservoir, flush openings on opposite faces and independently dispersing schematic molecules',captions:{release:'Particles dispersing from both reservoir faces',structure:'Stent lattice · smaller square reservoir',reservoir:'Two flush openings · release from both faces'}},
  lipid:{factory:createLipidNanoparticle,global:'portfolioLipidMode',initial:'release',label:'Lipid carrier with dual encapsulated cargo and independent particles dispersing in an initial burst followed by sustained release',captions:{release:'Burst then sustained release',structure:'Lipid carrier structure',cargo:'Dual encapsulated cargo'}}
 }[project];
 if(config){
  const lab=view.closest('.design-lab')||view.parentElement,motion=lab.querySelector('[data-design-motion]'),status=lab.querySelector('[data-design-status]'),reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let renderer=null,scene,camera,model,orbit,visible=false,paused=reduced.matches,clock=0,last=0,frameId=0;
  const sync=()=>{if(motion){motion.textContent=paused?'Resume animation':'Pause animation';motion.setAttribute('aria-pressed',String(paused));}};
  function render(){
   if(!renderer||!model)return;model.animate(clock);renderer.render(scene,camera);
   const text=model.getPhase?.()||config.captions[model.getMode()]||'Concept view';if(status&&status.textContent!==text)status.textContent=text;
  }
  function frame(now){
   frameId=0;if(!renderer||document.hidden||!visible||document.querySelector('dialog[open]')){last=0;return;}
   const dt=last?Math.min(.06,(now-last)/1000):0;last=now;if(!paused)clock+=dt;render();if(!paused)frameId=requestAnimationFrame(frame);
  }
  function request(){if(renderer&&!frameId&&!document.hidden&&visible)frameId=requestAnimationFrame(frame);}
  function fallback(){
   if(frameId)cancelAnimationFrame(frameId);frameId=0;view.classList.remove('scene-ready');view.dataset.ready='false';
   if(motion)motion.disabled=true;for(const button of lab.querySelectorAll('[data-design-mode]'))button.disabled=true;
   if(status)status.textContent='3D unavailable · concept illustration shown';
  }
  try{
   if(!config.captions[window[config.global]])window[config.global]=config.initial;
   renderer=new THREE.WebGLRenderer({alpha:true,antialias:true});renderer.setPixelRatio(Math.min(2,devicePixelRatio||1));renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;
   renderer.domElement.setAttribute('role','img');renderer.domElement.setAttribute('aria-label',config.label);renderer.domElement.style.touchAction='pan-y';view.append(renderer.domElement);
   scene=new THREE.Scene();camera=new THREE.PerspectiveCamera(37,1,.1,50);camera.position.set(4.3,2.5,6.5);camera.lookAt(0,.15,0);
   scene.add(new THREE.HemisphereLight(0xf0f8f1,0x26372e,2.6));
   for(const [color,intensity,position]of [[0xfff2df,4,[3,6,4]],[0xa4d9eb,2,[-4,3,-3]],[0xff8a45,1,[4,2,-3]]]){const light=new THREE.DirectionalLight(color,intensity);light.position.set(...position);scene.add(light);}
   model=config.factory();model.setMode(window[config.global]);orbit=new THREE.Group();orbit.add(model.group);scene.add(orbit);view.classList.add('scene-ready');view.dataset.ready='true';
   let pointer=null;
   renderer.domElement.addEventListener('pointerdown',event=>{if(!renderer||event.pointerType!=='mouse'||event.button!==0)return;pointer={id:event.pointerId,x:event.clientX,y:event.clientY};renderer.domElement.setPointerCapture(event.pointerId);view.classList.add('is-dragging');});
   renderer.domElement.addEventListener('pointermove',event=>{if(!renderer||!pointer||pointer.id!==event.pointerId)return;orbit.rotation.y+=(event.clientX-pointer.x)*.008;orbit.rotation.x=THREE.MathUtils.clamp(orbit.rotation.x+(event.clientY-pointer.y)*.003,-.35,.35);pointer.x=event.clientX;pointer.y=event.clientY;render();});
   const release=()=>{pointer=null;view.classList.remove('is-dragging');};for(const name of ['pointerup','pointercancel','lostpointercapture'])renderer.domElement.addEventListener(name,release);
   new ResizeObserver(()=>{if(!renderer)return;const w=view.clientWidth,h=view.clientHeight;if(!w||!h)return;camera.aspect=w/h;camera.zoom=Math.min(1.1,w/h*1.25);camera.updateProjectionMatrix();renderer.setSize(w,h,false);render();}).observe(view);
   new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;last=0;request();},{threshold:.03}).observe(view);
   addEventListener('design:mode',event=>{if(event.detail?.project!==project||!config.captions[event.detail.mode])return;model.setMode(event.detail.mode);clock=0;last=0;render();request();});
   motion?.addEventListener('click',()=>{paused=!paused;sync();last=0;request();});
   reduced.addEventListener('change',event=>{if(event.matches)paused=true;sync();last=0;request();});
   document.addEventListener('visibilitychange',()=>{last=0;request();});addEventListener('portfolio:dialog',()=>{last=0;request();});
   renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();fallback();renderer=null;});
   sync();render();
  }catch(error){renderer?.dispose();renderer=null;fallback();console.warn(project+' concept fallback:',error.message);}
 }
}
