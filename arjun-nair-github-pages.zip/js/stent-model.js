import * as T from 'three';

// Original schematic release illustration. Particle paths and timing are presentation
// effects, not drug identity, dosage, release kinetics, blood flow or clinical results.
const pearl=new T.MeshStandardMaterial({color:0xd7e0d6,metalness:.62,roughness:.3});
const dark=new T.MeshStandardMaterial({color:0x273b40,metalness:.48,roughness:.4});
const orange=new T.MeshStandardMaterial({color:0xfca16b,metalness:.24,roughness:.38});
const mint=new T.MeshStandardMaterial({color:0x8edbc8,metalness:.2,roughness:.42});
const membrane=new T.MeshStandardMaterial({color:0x85bcbd,transparent:true,opacity:.065,side:T.DoubleSide,depthWrite:false,roughness:.6});
const sphereGeometry=new T.SphereGeometry(.036,12,8);
function mesh(g,geo,mat,x=0,y=0,z=0){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;g.add(m);return m;}
function box(g,w,h,d,mat,x=0,y=0,z=0){return mesh(g,new T.BoxGeometry(w,h,d),mat,x,y,z);}
function cyl(g,r,h,mat,x=0,y=0,z=0){return mesh(g,new T.CylinderGeometry(r,r,h,48),mat,x,y,z);}
function bond(g,a,b,r=.016,mat=pearl){const p=new T.Vector3(...a),q=new T.Vector3(...b),d=q.clone().sub(p),m=cyl(g,r,d.length(),mat);m.position.copy(p.add(q).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());return m;}
function torus(g,r,t,mat,x=0,y=0,z=0){return mesh(g,new T.TorusGeometry(r,t,10,64),mat,x,y,z);}
function label(g){
 if(typeof document==='undefined')return;const canvas=document.createElement('canvas');canvas.width=900;canvas.height=126;const ctx=canvas.getContext('2d');ctx.fillStyle='#14201a';ctx.fillRect(0,0,900,126);ctx.strokeStyle='#425c50';ctx.strokeRect(1,1,898,124);ctx.fillStyle='#c3dbd0';ctx.font='500 30px monospace';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('SMART STENT / RELEASE CONCEPT',450,61);const map=new T.CanvasTexture(canvas);map.colorSpace=T.SRGBColorSpace;mesh(g,new T.PlaneGeometry(3.08,.43),new T.MeshBasicMaterial({map}),0,1.65,0);
}
function flushPorts(g){
 const face=(w,h)=>{const s=new T.Shape();s.moveTo(-w/2,-h/2);s.lineTo(w/2,-h/2);s.lineTo(w/2,h/2);s.lineTo(-w/2,h/2);s.closePath();const hole=new T.Path();hole.absarc(0,0,.026,0,Math.PI*2,true);s.holes.push(hole);return s;};
 const body=mesh(g,new T.ExtrudeGeometry(face(.24,.26),{depth:.07,bevelEnabled:false,curveSegments:28}),orange,0,0,-.035);body.name='small-square-reservoir-body';
 for(const side of [1,-1]){const panel=mesh(g,new T.ShapeGeometry(face(.218,.238),28),dark,0,0,side*.0354);if(side<0)panel.rotation.y=Math.PI;panel.name=side>0?'outer-flush-reservoir-face':'inner-flush-reservoir-face';}
 const channel=mesh(g,new T.CylinderGeometry(.026,.026,.07,32,1,true),new T.MeshStandardMaterial({color:0x101b1d,roughness:.7,side:T.DoubleSide}));channel.rotation.x=Math.PI/2;channel.name='flush-through-hole';
 return [new T.Vector3(0,0,.036),new T.Vector3(0,0,-.036)];
}
const hash=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453123;return x-Math.floor(x);};
const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};

export function createSmartStent(){
 const group=new T.Group();group.scale.setScalar(.87);group.position.y=.11;label(group);
 cyl(group,1.52,.055,new T.MeshStandardMaterial({color:0x25382f,roughness:.64,metalness:.22}),0,-1.39,0);const rim=torus(group,1.49,.01,mint,0,-1.356,0);rim.rotation.x=Math.PI/2;
 const system=new T.Group();group.add(system);
 const stent=new T.Group();stent.position.set(-.35,0,-.12);stent.rotation.z=-.10;system.add(stent);stent.name='stent-lattice';
 const count=16,rows=8,r=.61;
 for(let row=0;row<rows;row++)for(let i=0;i<count;i++){
  const a=i/count*Math.PI*2,b=(i+1)/count*Math.PI*2,y=-.95+row*.28,p=[Math.cos(a)*r,y+(i%2)*.10,Math.sin(a)*r],q=[Math.cos(b)*r,y+((i+1)%2)*.10,Math.sin(b)*r];
  bond(stent,p,q,.018,pearl);if(row<rows-1&&i%4===row%4)bond(stent,p,[p[0],p[1]+.28,p[2]],.018,i%2?pearl:mint);
 }
 const context=new T.Group();system.add(context);context.position.copy(stent.position);context.rotation.copy(stent.rotation);context.name='subtle-environment-context';
 mesh(context,new T.CylinderGeometry(.86,.86,2.40,64,1,true),membrane,0,.07,0);
 for(const y of [-1.13,1.27]){const line=torus(context,.86,.006,new T.MeshBasicMaterial({color:0x6a9592,transparent:true,opacity:.34}),0,y,0);line.rotation.x=Math.PI/2;}
 // The original orange square module IS the reservoir, not a second sensor.
 const reservoir=new T.Group();stent.add(reservoir);reservoir.position.set(0,.12,.61);reservoir.name='square-reservoir-module';
 const ports=flushPorts(reservoir);
 const emitter=new T.Group();reservoir.add(emitter);emitter.name='port-originating-particles';
 const particles=[],colors=[0xf4a16f,0x8de0c9,0x8eb9dc];
 for(let i=0;i<42;i++){
  const type=i%3,mat=new T.MeshStandardMaterial({color:colors[type],emissive:colors[type],emissiveIntensity:.12,metalness:.05,roughness:.42,transparent:true,opacity:0,depthWrite:false});
  const molecule=mesh(emitter,sphereGeometry,mat);molecule.name='individual-unlinked-molecule';molecule.castShadow=false;
  const angle=i*2.3999632297+hash(i+7)*.63,radius=.46+hash(i+13)*.69;
  particles.push({molecule,mat,seed:((i*17)%42+.37)/42,side:i%2===0?1:-1,angle,dx:Math.cos(angle)*radius,dy:Math.sin(angle)*radius*.95,dz:.14+hash(i+31)*.56,size:.65+hash(i+53)*.53});
 }
 let mode='release',phase='Particles dispersing from both reservoir faces';
 function setMode(value){
  mode=['release','structure','reservoir'].includes(value)?value:'release';const detail=mode==='reservoir';stent.visible=!detail;context.visible=!detail;emitter.visible=mode!=='structure';
  // Detail magnifies the very same square module; release reattaches it to the stent.
  (detail?system:stent).add(reservoir);reservoir.position.set(detail?-.30:0,detail?-.05:.12,detail?0:.61);reservoir.scale.setScalar(detail?2.25:1);reservoir.rotation.y=detail?.50:0;
  phase=mode==='structure'?'Stent lattice · smaller square reservoir':detail?'Two flush openings · release from both faces':'Particles dispersing from both reservoir faces';return mode;
 }
 function animate(t=0){
  if(!Number.isFinite(t))t=0;const requested=typeof window!=='undefined'?window.portfolioStentMode:mode;if(requested&&requested!==mode)setMode(requested);
  system.rotation.y=mode==='release'?Math.sin(t*.17)*.055:0;
  const extent=mode==='reservoir'?.48:1;
  particles.forEach(({molecule,mat,seed,side,angle,dx,dy,dz,size})=>{
   const age=((t*.13+seed)%1+1)%1,spread=1-Math.exp(-4.2*Math.max(0,age-.015)),exit=.12*smooth(age/.045),bend=Math.sin(age*Math.PI)*.055;
   // Every dot starts at the outlet, then rapidly spreads across both lateral
   // axes with independent depth and phase. No bonds, chains or orbital paths.
   const port=ports[side>0?0:1];molecule.position.set(port.x+(dx*spread+Math.cos(angle*1.7)*bend)*extent,port.y+(dy*spread+Math.sin(angle*1.3)*bend)*extent,port.z+side*(exit+dz*spread)*extent);
   molecule.scale.setScalar(size*(.82+.18*age));
   mat.opacity=Math.min(1,age/.035)*(1-smooth((age-.76)/.24))*.96;
  });
 }
 setMode(typeof window!=='undefined'?window.portfolioStentMode:'release');animate(0);
 return{group,animate,setMode,getMode:()=>mode,getPhase:()=>phase,getState:()=>({mode,particleCount:particles.length,port:ports[0].toArray(),ports:ports.map(p=>p.toArray()),particlesPerSide:particles.length/2})};
}
