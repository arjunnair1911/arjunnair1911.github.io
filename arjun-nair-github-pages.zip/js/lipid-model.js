import * as T from 'three';

// Schematic dual-cargo lipid-carrier illustration. The burst/sustained sequence
// is qualitative presentation motion, not measured release kinetics or dosage.
const pearl=new T.MeshStandardMaterial({color:0xd8e9dc,metalness:.16,roughness:.38,side:T.DoubleSide});
const mint=new T.MeshStandardMaterial({color:0x8acdbc,metalness:.14,roughness:.39});
const innerMint=new T.MeshStandardMaterial({color:0x5faaa5,metalness:.12,roughness:.42,side:T.DoubleSide});
const cargoColors=[0xf2a16c,0x8dbedc];
const cargoMats=cargoColors.map(color=>new T.MeshStandardMaterial({color,emissive:color,emissiveIntensity:.08,metalness:.08,roughness:.37}));
const dotGeometry=new T.SphereGeometry(.027,12,8),crystalGeometry=new T.IcosahedronGeometry(.032,0);
const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
const hash=n=>{const s=Math.sin(n*127.1+311.7)*43758.5453123;return s-Math.floor(s);};
function mesh(g,geometry,material,x=0,y=0,z=0){const m=new T.Mesh(geometry,material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;g.add(m);return m;}
function label(g){
 if(typeof document==='undefined')return;const c=document.createElement('canvas');c.width=920;c.height=126;const ctx=c.getContext('2d');ctx.fillStyle='#14201a';ctx.fillRect(0,0,920,126);ctx.strokeStyle='#425e50';ctx.strokeRect(1,1,918,124);ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#c1dbd0';ctx.font='500 29px monospace';ctx.fillText('LIPID NANOCARRIER / RELEASE CONCEPT',460,60);const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;mesh(g,new T.PlaneGeometry(3.12,.43),new T.MeshBasicMaterial({map}),0,1.68,0);
}
function spherical(r,phi,theta){return new T.Vector3(-r*Math.cos(phi)*Math.sin(theta),r*Math.cos(theta),r*Math.sin(phi)*Math.sin(theta));}
function membraneEdge(g,phi){
 const positions=[],indices=[];for(let i=0;i<=36;i++){const theta=i/36*Math.PI;for(const r of[.73,.85])positions.push(...spherical(r,phi,theta).toArray());if(i<36){const j=i*2;indices.push(j,j+1,j+2,j+1,j+3,j+2);}}
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setIndex(indices);geo.computeVertexNormals();mesh(g,geo,pearl);
 const path=Array.from({length:37},(_,i)=>spherical(.85,phi,i/36*Math.PI));mesh(g,new T.TubeGeometry(new T.CatmullRomCurve3(path),64,.014,6,false),mint);
}
function createMembrane(g){
 // The front wedge is a visual cutaway, not a literal defect in the carrier.
 const cutStart=1.40,cutEnd=2.90,span=Math.PI*2-(cutEnd-cutStart);
 mesh(g,new T.SphereGeometry(.85,64,40,cutEnd,span),pearl);
 mesh(g,new T.SphereGeometry(.73,64,40,cutEnd,span),innerMint);
 membraneEdge(g,cutStart);membraneEdge(g,cutEnd);
 const heads=new T.InstancedMesh(new T.SphereGeometry(.026,10,8),mint,180),inside=new T.InstancedMesh(new T.SphereGeometry(.018,8,6),pearl,180),dummy=new T.Object3D();let count=0;
 for(let i=0;i<180;i++){
  const y=1-(i+.5)/180*2,theta=Math.acos(y),phi=(i*Math.PI*(3-Math.sqrt(5)))%(Math.PI*2);if(phi>cutStart&&phi<cutEnd)continue;
  dummy.position.copy(spherical(.866,phi,theta));dummy.updateMatrix();heads.setMatrixAt(count,dummy.matrix);dummy.position.copy(spherical(.716,phi,theta));dummy.updateMatrix();inside.setMatrixAt(count++,dummy.matrix);
 }
 heads.count=inside.count=count;heads.castShadow=true;heads.receiveShadow=true;g.add(heads,inside);
}

export function createLipidNanoparticle(){
 const group=new T.Group();group.scale.setScalar(.86);group.position.y=.10;label(group);
 mesh(group,new T.CylinderGeometry(1.52,1.52,.055,72),new T.MeshStandardMaterial({color:0x23382e,metalness:.2,roughness:.66}),0,-1.39,0);
 const rim=mesh(group,new T.TorusGeometry(1.49,.01,8,80),mint,0,-1.356,0);rim.rotation.x=Math.PI/2;
 const carrier=new T.Group();group.add(carrier);carrier.position.y=-.02;carrier.name='cutaway-lipid-carrier';createMembrane(carrier);
 mesh(carrier,new T.SphereGeometry(.69,32,20),new T.MeshStandardMaterial({color:0x8dbfb0,transparent:true,opacity:.07,depthWrite:false,side:T.DoubleSide,roughness:.6}));
 const cargo=new T.Group();carrier.add(cargo);cargo.name='dual-encapsulated-cargo';
 for(let i=0;i<14;i++){
  const y=1-(i+.5)/14*2,angle=i*2.3999632297,r=.26+.20*hash(i+7),x=Math.cos(angle)*Math.sqrt(1-y*y)*r,z=Math.sin(angle)*Math.sqrt(1-y*y)*r;
  const geometry=i%2?new T.IcosahedronGeometry(.083,1):new T.SphereGeometry(.075,16,10);const m=mesh(cargo,geometry,cargoMats[i%2],x,y*r,z);m.name=i%2?'cargo-b':'cargo-a';
 }
 const emission=new T.Group();carrier.add(emission);emission.name='independent-released-drug-symbols';
 const particles=[];
 for(let i=0;i<54;i++){
  const kind=i%2,color=cargoColors[kind],material=new T.MeshStandardMaterial({color,emissive:color,emissiveIntensity:.12,metalness:.04,roughness:.38,transparent:true,opacity:0,depthWrite:false});
  const object=mesh(emission,kind?crystalGeometry:dotGeometry,material);object.castShadow=false;object.name='individual-released-drug';
  const y=1-(i+.5)/54*2,angle=i*2.3999632297+hash(i+21)*.37,direction=new T.Vector3(Math.cos(angle)*Math.sqrt(1-y*y),y,Math.sin(angle)*Math.sqrt(1-y*y));
  const tangent=new T.Vector3(-direction.z,0,direction.x).normalize();if(tangent.lengthSq()<.1)tangent.set(1,0,0);
  particles.push({object,material,direction,tangent,phase:hash(i+49),size:.72+hash(i+73)*.55,burst:i<36,travel:.55+hash(i+101)*.20});
 }
 let mode='release',phase='Initial burst release',activeCount=0,timeOrigin=0,restartPending=true;
 function setMode(value){
  mode=['release','structure','cargo'].includes(value)?value:'release';emission.visible=mode==='release';carrier.scale.setScalar(mode==='cargo'?1.25:1);carrier.rotation.set(0,0,0);restartPending=true;
  phase=mode==='structure'?'Lipid carrier structure':mode==='cargo'?'Dual encapsulated cargo':'Initial burst release';return mode;
 }
 function animate(t=0){
  if(!Number.isFinite(t))t=0;const requested=typeof window!=='undefined'?window.portfolioLipidMode:mode;if(requested&&requested!==mode)setMode(requested);
  if(restartPending){timeOrigin=t;restartPending=false;}const elapsed=Math.max(0,t-timeOrigin);
  const time=elapsed%14;carrier.rotation.y=mode==='release'?Math.sin(elapsed*.17)*.06:0;
  if(mode==='release')phase=time<2.2?'Initial burst release':'Sustained release';activeCount=0;
  const resetFade=1-smooth((time-12.9)/1.1);
  particles.forEach(({object,material,direction,tangent,phase:offset,size,burst,travel})=>{
   let age,opacity=0;if(burst){age=(time+.28+offset*.55)/1.8;if(age<1)opacity=Math.min(1,age/.07)*(1-smooth((age-.67)/.33));}
   else{age=(((time-1.25)*.18+offset)%1+1)%1;if(time>1.25)opacity=Math.min(1,age/.10)*(1-smooth((age-.76)/.24));}
   const progress=Math.max(0,Math.min(1,age)),spread=burst?1-Math.exp(-3.5*progress):progress;
   object.position.copy(direction).multiplyScalar(.866+travel*spread).addScaledVector(tangent,Math.sin(progress*Math.PI)*.11*(offset-.5));
   object.scale.setScalar(size*(.86+.14*progress));object.rotation.set(offset,progress*1.2,offset*.7);material.opacity=opacity*resetFade*.96;if(mode==='release'&&material.opacity>.25)activeCount++;
  });
 }
 setMode(typeof window!=='undefined'?window.portfolioLipidMode:'release');animate(0);
 return{group,animate,setMode,restart:()=>{restartPending=true;},getMode:()=>mode,getPhase:()=>phase,getState:()=>({mode,phase,particleCount:particles.length,visibleParticleCount:activeCount,cargoTypes:2})};
}
