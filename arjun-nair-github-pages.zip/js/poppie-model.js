import * as T from 'three';

// Original five-petal concept geometry for a product-only mechanical illustration.
// It is not a tested prototype, validated mechanism or reproduction of the supplied commercial photos.
const blue=new T.MeshStandardMaterial({color:0x72a9d6,metalness:.12,roughness:.43,side:T.DoubleSide});
const blueDark=new T.MeshStandardMaterial({color:0x386784,metalness:.3,roughness:.35});
const pearl=new T.MeshStandardMaterial({color:0xdfe8df,metalness:.25,roughness:.29});
const metal=new T.MeshStandardMaterial({color:0x9fb8c1,metalness:.55,roughness:.28});
const orange=new T.MeshStandardMaterial({color:0xdc9b69,metalness:.18,roughness:.4});
const clearBlue=new T.MeshPhysicalMaterial({color:0x8abbd4,metalness:.03,roughness:.18,transparent:true,opacity:.22,depthWrite:false,side:T.DoubleSide});
const edgeMat=new T.LineBasicMaterial({color:0xa9cee1,transparent:true,opacity:.68});
const mix=(a,b,t)=>a+(b-a)*t;
const ease=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
const smooth=(a,b,x)=>ease((x-a)/(b-a));
function mesh(g,geo,mat,x=0,y=0,z=0){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;g.add(m);return m;}
function cyl(g,r,h,mat,x=0,y=0,z=0){return mesh(g,new T.CylinderGeometry(r,r,h,64),mat,x,y,z);}
function ring(g,r,t,mat,x=0,y=0,z=0){const o=mesh(g,new T.TorusGeometry(r,t,10,64),mat,x,y,z);o.rotation.x=Math.PI/2;return o;}
function box(g,w,h,d,mat,x=0,y=0,z=0){return mesh(g,new T.BoxGeometry(w,h,d),mat,x,y,z);}
function annulus(g,ro,ri,h,material,x=0,y=0,z=0){
 const shape=new T.Shape();shape.absarc(0,0,ro,0,Math.PI*2,false);const hole=new T.Path();hole.absarc(0,0,ri,0,Math.PI*2,true);shape.holes.push(hole);
 const geo=new T.ExtrudeGeometry(shape,{depth:h,bevelEnabled:false,curveSegments:64});geo.rotateX(Math.PI/2);geo.translate(0,h/2,0);return mesh(g,geo,material,x,y,z);
}
function label(g){
 if(typeof document==='undefined')return;
 const c=document.createElement('canvas');c.width=900;c.height=142;const ctx=c.getContext('2d');ctx.fillStyle='#14201b';ctx.fillRect(0,0,900,142);ctx.strokeStyle='#405c51';ctx.strokeRect(1,1,898,140);ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#c3ddda';ctx.font='500 29px monospace';ctx.fillText('POPPIE / FIVE-PETAL CONCEPT',450,49);ctx.fillStyle='#8caaa1';ctx.font='500 18px monospace';ctx.fillText('CONCEPT GEOMETRY · NOT A TESTED PROTOTYPE',450,99);
 const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;mesh(g,new T.PlaneGeometry(3.05,.48),new T.MeshBasicMaterial({map}),0,1.74,0);
}

function makePetal(parent,angle){
 const ns=20,nw=10,row=nw+1,sideCount=(ns+1)*row,positions=new Float32Array(sideCount*2*3),indices=[];
 for(let side=0;side<2;side++)for(let s=0;s<ns;s++)for(let w=0;w<nw;w++){
  const a=side*sideCount+s*row+w,b=a+row,c=b+1,d=a+1;
  if(side===0)indices.push(a,d,b,b,d,c);else indices.push(a,b,d,b,c,d);
 }
 // Join the sheet boundary into one rounded-looking solid petal.
 const join=(a,b)=>indices.push(a,a+sideCount,b,b,a+sideCount,b+sideCount);
 for(let s=0;s<ns;s++){join(s*row,(s+1)*row);join(s*row+nw,(s+1)*row+nw);}
 for(let w=0;w<nw;w++){join(w,w+1);join(ns*row+w,ns*row+w+1);}
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.BufferAttribute(positions,3));geo.setIndex(indices);
 const petal=mesh(parent,geo,blue);petal.name='original-five-petal-support';
 const edgePosition=new Float32Array((ns*2+3)*3),edgeGeo=new T.BufferGeometry();edgeGeo.setAttribute('position',new T.BufferAttribute(edgePosition,3));const edge=new T.Line(edgeGeo,edgeMat);parent.add(edge);
 function point(s,q,fold,underside=false){
  const radial=mix(.13+1.00*s,.13+.060*Math.sin(Math.PI*s),fold);
  const yOpen=.22+.43*Math.sin(Math.PI*s*.9)-.12*s;
  const yClosed=.22+1.03*s;
  const halfWidth=(.027+.31*Math.pow(Math.sin(Math.PI*s),.72))*mix(1,.22,fold);
  const crown=.065*(1-q*q)*Math.sin(Math.PI*s)*mix(1,.5,fold),thickness=.015*(.6+.4*Math.sin(Math.PI*s));
  return [Math.cos(angle)*radial-Math.sin(angle)*q*halfWidth,mix(yOpen,yClosed,fold)+crown+(underside?-thickness:thickness),Math.sin(angle)*radial+Math.cos(angle)*q*halfWidth];
 }
 function update(fold){
  let i=0;for(let side=0;side<2;side++)for(let s=0;s<=ns;s++)for(let w=0;w<=nw;w++){
   const p=point(s/ns,w/nw*2-1,fold,side===1);positions[i++]=p[0];positions[i++]=p[1];positions[i++]=p[2];
  }
  let j=0;for(let s=0;s<=ns;s++){const p=point(s/ns,-1,fold);edgePosition[j++]=p[0];edgePosition[j++]=p[1]+.004;edgePosition[j++]=p[2];}
  for(let s=ns;s>=0;s--){const p=point(s/ns,1,fold);edgePosition[j++]=p[0];edgePosition[j++]=p[1]+.004;edgePosition[j++]=p[2];}
  const p=point(0,-1,fold);edgePosition[j++]=p[0];edgePosition[j++]=p[1]+.004;edgePosition[j++]=p[2];
  geo.attributes.position.needsUpdate=true;geo.computeVertexNormals();geo.computeBoundingSphere();edgeGeo.attributes.position.needsUpdate=true;edgeGeo.computeBoundingSphere();
 }
 update(0);return {update,mesh:petal};
}

export function createPoppie(){
 const group=new T.Group();group.scale.setScalar(.88);group.position.y=.12;label(group);
 const turntable=new T.Group();group.add(turntable);turntable.rotation.y=-.18;
 cyl(group,1.5,.045,new T.MeshStandardMaterial({color:0x20312a,metalness:.25,roughness:.65}),0,-1.46,0);ring(group,1.48,.01,metal,0,-1.43,0);
 const support=new T.Group();turntable.add(support);support.name='concept-support';
 const petals=Array.from({length:5},(_,i)=>makePetal(support,i*Math.PI*2/5+Math.PI*.1));
 cyl(support,.19,.075,pearl,0,.19,0);ring(support,.19,.014,orange,0,.23,0);
 cyl(support,.065,.24,blueDark,0,.035,0);
 const pullLoop=mesh(support,new T.TorusGeometry(.115,.027,10,48),blueDark,0,-.2,0);pullLoop.scale.y=1.2;
 const sleeve=new T.Group();turntable.add(sleeve);sleeve.name='translucent-applicator-sleeve';
 mesh(sleeve,new T.CylinderGeometry(.30,.30,1.22,64,1,true),clearBlue);
 annulus(sleeve,.315,.265,.035,pearl,0,.61,0);annulus(sleeve,.315,.265,.035,blueDark,0,-.61,0);
 ring(sleeve,.30,.009,metal,0,.37,0);ring(sleeve,.30,.009,metal,0,-.38,0);
 for(let i=0;i<6;i++)box(sleeve,i%2?.036:.06,.006,.008,pearl,.14,(i-2.5)*.115,.267).rotation.y=-.45;
 const plunger=new T.Group();turntable.add(plunger);plunger.name='separate-plunger';
 cyl(plunger,.055,.87,metal,0,-.85,0);cyl(plunger,.19,.055,pearl,0,-.405,0);
 const thumb=box(plunger,.59,.055,.21,blueDark,0,-1.315,0);thumb.name='plunger-thumb-bar';ring(plunger,.10,.008,orange,0,-1.265,0);
 let mode='cycle',phase='Expanded support',fold=0,lastFold=-1,sleeveTravel=0;
 function pose(nextFold,travel,nextPhase){
  fold=nextFold;sleeveTravel=travel;phase=nextPhase;sleeve.position.y=mix(-.64,.70,travel);
  if(Math.abs(fold-lastFold)>.0001){petals.forEach(p=>p.update(fold));lastFold=fold;}
 }
 function setMode(value){
  mode=['cycle','expanded','compressed'].includes(value)?value:'cycle';
  if(mode==='compressed')pose(1,1,'Compressed inside sleeve');else pose(0,0,'Expanded support');
  return mode;
 }
 function animate(t=0){
  const requested=typeof window!=='undefined'?window.portfolioPoppieMode:mode;if(requested&&requested!==mode)setMode(requested);
  if(mode==='cycle'){
   const time=((t%13)+13)%13;
   if(time<2.2)pose(0,0,'Expanded support');
   else if(time<5.1){const travel=ease((time-2.2)/2.9);pose(smooth(.12,.86,travel),travel,'Sleeve compressing petals');}
   else if(time<7.3)pose(1,1,'Compressed inside sleeve');
   else if(time<10.7){const travel=1-ease((time-7.3)/3.4);pose(smooth(.12,.86,travel),travel,'Sleeve releasing petals');}
   else pose(0,0,'Expanded support');
  }
  turntable.rotation.y=-.18;
 }
 setMode(typeof window!=='undefined'?window.portfolioPoppieMode:'cycle');
 return {group,animate,setMode,getMode:()=>mode,getPhase:()=>phase,getState:()=>({mode,phase,fold,sleeveTravel,petals:5})};
}
