(()=>{
 'use strict';
 const settings={
  poppie:{global:'portfolioPoppieMode',initial:'cycle',labels:{cycle:'Animated fold and release',expanded:'Expanded support',compressed:'Compressed inside sleeve'}},
  scaffold:{global:'portfolioScaffoldMode',initial:'structure',labels:{structure:'Design concept',printing:'Layer build',cells:'Cell distribution'}},
  stent:{global:'portfolioStentMode',initial:'release',labels:{release:'Particles dispersing from both reservoir faces',structure:'Stent lattice · smaller square reservoir',reservoir:'Two flush openings · release from both faces'}},
  lipid:{global:'portfolioLipidMode',initial:'release',labels:{release:'Burst then sustained release',structure:'Lipid carrier structure',cargo:'Dual encapsulated cargo'}}
 };
 for(const config of Object.values(settings))if(!config.labels[window[config.global]])window[config.global]=config.initial;
 const wrappers=[...document.querySelectorAll('[data-design-controls]')];
 function sync(project){
  const config=settings[project];if(!config)return;
  for(const wrapper of wrappers.filter(w=>w.dataset.designControls===project))for(const button of wrapper.querySelectorAll('[data-design-mode]'))button.setAttribute('aria-pressed',String(button.dataset.designMode===window[config.global]));
 }
 for(const wrapper of wrappers){
  const project=wrapper.dataset.designControls,config=settings[project];if(!config)continue;sync(project);
  wrapper.addEventListener('click',event=>{
   const button=event.target.closest('[data-design-mode]');if(!button||!wrapper.contains(button)||button.disabled)return;
   const mode=button.dataset.designMode;if(!config.labels[mode])return;
   window[config.global]=mode;sync(project);
   for(const lab of document.querySelectorAll('.design-lab'))if(lab.querySelector('[data-design-viewer]')?.dataset.designViewer===project)for(const status of lab.querySelectorAll('[data-design-status]'))status.textContent=config.labels[mode];
   dispatchEvent(new CustomEvent('design:mode',{detail:{project,mode}}));
  });
 }
})();
